# 模型更新 — 2026年7月

## 新模型性能

| 指标 | 旧模型 (v1) | 新模型 | 提升 |
|---|---|---|---|
| 训练数据 | 142,848 行 / 8 天 | **316,386 行 / 37 天** | 2.2× |
| CV MAE | 0.0708 | **0.0462** | -35% |
| CV RMSE | 0.1093 | **0.0744** | -32% |
| Hold-out R² | — | **0.8647** | — |

---

## 操作步骤

### 1. 克隆仓库
```bash
git clone https://github.com/LuoX11a/CP3407-Project.git
cd CP3407-Project
```

### 2. 切换到 feature 分支
```bash
git checkout feature
```

### 3. 复制文件
把这个文件夹里的内容覆盖到仓库根目录。只需覆盖 `ml/` 目录下的文件。

### 4. 提交
```bash
git add ml/
git commit -m "feat: retrain LightGBM model with extended 37-day dataset

- 316K training rows across 37 days (up from 143K / 8 days)
- CV MAE: 0.0462 (improved 35% from 0.0708)
- CV RMSE: 0.0744 (improved 32% from 0.1093)
- Hold-out R²: 0.8647"
```

### 5. 推送
```bash
git push origin feature
```

### 6. 创建 PR
打开 https://github.com/LuoX11a/CP3407-Project/pull/new/feature

- **Base**: `main` ← **Compare**: `feature`
- 标题填上面的 commit message
- 点 Create pull request

---

PR 创建后直接 merge，不需要审批。
